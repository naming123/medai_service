"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation"; // useRouter로 상세 페이지 이동
import { supabase } from "../supabaseClient";
import "../../styles/style.css";

type Post = {
  id: number;
  title: string;
  description: string; // 예시로 추가한 필드
};

export default function Blog() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter(); // useRouter 훅 사용

  useEffect(() => {
    async function fetchPosts() {
      try {
        const { data, error } = await supabase.from("post").select();
        if (error) throw error;
        setPosts(data || []);
      } catch (error) {
        console.error("Fetch error:", error);
        setError("Failed to fetch posts.");
      } finally {
        setLoading(false);
      }
    }
    fetchPosts();
  }, []);

  const deletePost = async (id: number) => {
    try {
      const { error } = await supabase.from("post").delete().eq("id", id);

      if (error) throw error;
      alert("Post deleted successfully");
      setPosts(posts.filter((post) => post.id !== id)); // 목록에서 삭제된 포스트 제거
    } catch (error) {
      console.error("Delete error:", error);
      alert("Failed to delete post");
    }
  };

  const updatePost = async (id: number, newTitle: string) => {
    try {
      const { error } = await supabase
        .from("post")
        .update({ title: newTitle }) // 새로운 제목으로 업데이트
        .eq("id", id);

      if (error) throw error;
      alert("Post updated successfully");

      setPosts(
        posts.map((post) =>
          post.id === id ? { ...post, title: newTitle } : post
        )
      ); // 목록에서 수정된 포스트 업데이트
    } catch (error) {
      console.error("Update error:", error);
      alert("Failed to update post");
    }
  };

  if (loading) return <p>Loading posts...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <h1>Blog Posts</h1>
      <ul>
        {posts.map((post) => (
          <li key={post.id}>
            {/* 상세 페이지로 이동하는 링크 추가 */}
            <a href={`/posts/${post.id}`}>
              <h2>{post.title}</h2>
            </a>
            <p>{post.description}</p>
            {/* 수정 버튼 */}
            <button
              onClick={() => {
                const newTitle = prompt("Enter new title:", post.title);
                if (newTitle) updatePost(post.id, newTitle);
              }}
            >
              Edit
            </button>
            {/* 삭제 버튼 */}
            <button onClick={() => deletePost(post.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
