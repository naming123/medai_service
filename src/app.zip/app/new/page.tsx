"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../supabaseClient";
import "../../styles/style.css";

type Post = {
  title: string;
  content: string;
  user_id: number;
};
const user_id = 1;
export default function NewPost() {
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false); // 로딩 상태 추가
  const router = useRouter();

  const testUpdate = async (post: Post) => {
    const { data, error } = await supabase.from("post").insert([
      {
        title: post.title,
        content: post.content,
        user_id: post.user_id,
      }, // 추가하고자 하는 레코드 데이터를 객체 형태로 지정
    ]);

    if (error) {
      console.error("Error updating post:", error);
    } else {
      console.log("Post updated successfully:", data);
    }
    // 로딩 상태를 false로 변경
    setLoading(false);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true); // 로딩 시작
    const newPost: Post = { title, content, user_id };
    await testUpdate(newPost);
  };

  return (
    <div>
      <h1>Create a New Post</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Title:</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            disabled={loading} // 로딩 중이면 입력 비활성화
          />
        </div>
        <div>
          <label>Content:</label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
            disabled={loading} // 로딩 중이면 입력 비활성화
          />
        </div>
        <button type="submit" disabled={loading}>
          {loading ? "Creating..." : "Create Post"}
        </button>
      </form>
    </div>
  );
}
