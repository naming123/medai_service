// components/AnimatedComponent.js
"use client";

import { useRef } from "react";
import { useIntersectionObserver } from "../hooks/useIntersectionObserver";
import styles from "../../styles/AnimatedComponent.module.css";

export default function AnimatedComponent({ children }) {
  const elementRef = useRef(null);
  const isVisible = useIntersectionObserver(elementRef, {
    threshold: 0.1, // 10% 이상 보이면 트리거
  });

  return (
    <div
      ref={elementRef}
      className={`${styles.component} ${isVisible ? styles.animate : ""}`}
    >
      {children}
    </div>
  );
}
